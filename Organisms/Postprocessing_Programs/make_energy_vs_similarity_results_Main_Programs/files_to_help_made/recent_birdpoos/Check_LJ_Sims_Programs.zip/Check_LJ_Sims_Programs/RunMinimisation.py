'''
RunMinimisation.py, GRW, 8/6/17
 
This python program is designed to input the POSCAR file and use it
with Atomic Simulation Environment (ASE) to minimise the given structure
using an empirical potential.
 
The program will take the output translate it into a OUTCAR file which
the bpga will use.
 
Required inputs: BeforeOpt
Required to outputs: AfterOpt.traj, INFO.txt
Other outputs: Trajectory file.
 
'''
from ase import Atom, Atoms
from ase.io import read as ase_read
from ase.io import write as ase_write
#from ase.calculators.lj import LennardJones
import time
from ase.data import atomic_numbers
from asap3.Internal.BuiltinPotentials import LennardJones
from ase.optimize import BFGS, FIRE
import sys
 
from ase.visualize import view

def Minimisation_Function(cluster,calculator):
	####################################################################################################################
	# Read the BeforeOpt file and record the elements, the
	# number of each element in the cluster and their positions
	#cluster = ase_read("BeforeOpt",format='vasp')
	cluster.pbc = False
	####################################################################################################################
	#Construct atoms using the ASE class "Atoms".
	####################################################################################################################
	# Perform the local optimisation method on the cluster.
	cluster.set_calculator(calculator)
	dyn = FIRE(cluster,logfile=None)
	startTime = time.time(); converged = False
	try:
		dyn.run(fmax=0.01,steps=5000)
		converged = dyn.converged()
		if not converged:
			import os
			name = os.path.basename(os.getcwd())
			errorMessage = 'The optimisation of cluster ' + name + ' did not optimise completely.'
			print(errorMessage, file=sys.stderr)
			print(errorMessage)
	except:
		print('Local Optimiser Failed for some reason.')
	endTime = time.time()
	#ase_write('AfterOpt.traj',cluster)
	####################################################################################################################
	return cluster
